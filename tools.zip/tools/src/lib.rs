//! Spectrum Router: CLI と WebAssembly で共有するルール・採点・SVG 描画。
use rand::{Rng, SeedableRng};
use std::fmt::Write;

pub const DEFAULT_N: usize = 64;
pub const MAX_N: usize = 100;

#[derive(Clone, Debug)]
pub struct Input {
    pub n: usize,
    pub a: Vec<usize>,
}

impl std::fmt::Display for Input {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        writeln!(f, "{}", self.n)?;
        for (i, a) in self.a.iter().enumerate() {
            if i > 0 {
                write!(f, " ")?;
            }
            write!(f, "{a}")?;
        }
        writeln!(f)
    }
}

pub fn parse_input(s: &str) -> Result<Input, String> {
    let mut tokens = s.split_whitespace();
    let n = tokens
        .next()
        .ok_or("入力が空です")?
        .parse::<usize>()
        .map_err(|_| "N が整数ではありません")?;
    if !(1..=MAX_N).contains(&n) {
        return Err(format!("N は 1..={MAX_N} の範囲で指定してください"));
    }
    let mut a = Vec::with_capacity(4 * n);
    let mut seen = vec![false; 4 * n + 1];
    for i in 0..4 * n {
        let v = tokens
            .next()
            .ok_or_else(|| format!("A_{i} がありません"))?
            .parse::<usize>()
            .map_err(|_| format!("A_{i} が整数ではありません"))?;
        if !(1..=4 * n).contains(&v) || seen[v] {
            return Err(format!(
                "A_{i}={v}: A は 1..={} の順列である必要があります",
                4 * n
            ));
        }
        seen[v] = true;
        a.push(v);
    }
    if tokens.next().is_some() {
        return Err("入力に余分なトークンがあります".into());
    }
    Ok(Input { n, a })
}

#[derive(Clone, Debug)]
pub struct Output {
    pub board: Vec<Vec<u8>>,
}

pub fn parse_output(input: &Input, s: &str) -> Result<Output, String> {
    // 末尾の改行・空白のみ許容し、空行や行頭の空白は盤面として受理しない。
    let rows: Vec<_> = s.trim_end().lines().collect();
    if rows.len() != input.n {
        return Err(format!(
            "出力は {} 行必要です（実際: {} 行）",
            input.n,
            rows.len()
        ));
    }
    let mut board = Vec::with_capacity(input.n);
    for (r, row) in rows.iter().enumerate() {
        let row = row.strip_suffix('\r').unwrap_or(row);
        if row.len() != input.n {
            return Err(format!(
                "行 {r} の長さは {} 必要です（実際: {}）",
                input.n,
                row.len()
            ));
        }
        if let Some(c) = row.bytes().position(|b| !b"012".contains(&b)) {
            return Err(format!(
                "マス ({r},{c}) の文字が不正です。使用可能な文字: 0 1 2"
            ));
        }
        board.push(
            row.bytes()
                .map(|b| match b {
                    b'0' => b'.',
                    b'1' => b'/',
                    b'2' => b'\\',
                    _ => unreachable!(),
                })
                .collect(),
        );
    }
    Ok(Output { board })
}

pub fn gen(seed: u64, n: usize) -> Result<Input, String> {
    if !(1..=MAX_N).contains(&n) {
        return Err(format!("N は 1..={MAX_N} の範囲で指定してください"));
    }
    let mut rng = rand_chacha::ChaCha20Rng::seed_from_u64(seed);
    let mut a: Vec<_> = (1..=4 * n).collect();
    // usize の乱数を使わず、native / wasm32 で同じ入力を生成する。
    for i in (1..a.len()).rev() {
        let j = rng.gen_range(0..=i as u32) as usize;
        a.swap(i, j);
    }
    Ok(Input { n, a })
}

// 進行方向: 上=0、右=1、下=2、左=3。
pub fn reflect(cell: u8, d: usize) -> usize {
    match cell {
        b'/' => d ^ 1,
        b'\\' => d ^ 3,
        _ => d,
    }
}

/// 入口から最初に入るマスと進行方向。
pub fn entrance(n: usize, i: usize) -> (usize, usize, usize) {
    match i / n {
        0 => (0, i, 2),
        1 => (i - n, n - 1, 3),
        2 => (n - 1, 3 * n - 1 - i, 0),
        3 => (4 * n - 1 - i, 0, 1),
        _ => unreachable!(),
    }
}

fn exit_index(n: usize, r: isize, c: isize) -> Option<usize> {
    if r < 0 {
        Some(c as usize)
    } else if c >= n as isize {
        Some(n + r as usize)
    } else if r >= n as isize {
        Some(3 * n - 1 - c as usize)
    } else if c < 0 {
        Some(4 * n - 1 - r as usize)
    } else {
        None
    }
}

#[derive(Clone, Debug)]
pub struct Route {
    pub exit: usize,
    /// 外周上の入口、通過マスの中心、外周上の出口。座標の単位はマス。
    pub points: Vec<(f64, f64)>,
}

pub fn port_point(n: usize, i: usize) -> (f64, f64) {
    let (r, c, _) = entrance(n, i);
    match i / n {
        0 => (c as f64 + 0.5, 0.),
        1 => (n as f64, r as f64 + 0.5),
        2 => (c as f64 + 0.5, n as f64),
        _ => (0., r as f64 + 0.5),
    }
}

pub fn trace(input: &Input, output: &Output, entry: usize) -> Result<Route, String> {
    if entry >= 4 * input.n {
        return Err("ポート番号が範囲外です".into());
    }
    let n = input.n;
    let (r, c, mut d) = entrance(n, entry);
    let (mut r, mut c) = (r as isize, c as isize);
    let mut points = vec![port_point(n, entry)];
    const DR: [isize; 4] = [-1, 0, 1, 0];
    const DC: [isize; 4] = [0, 1, 0, -1];
    // 有効な鏡配置では外周から入った経路は必ず外周に出る。
    // 方向付き状態数による上限を置き、実装上の無限ループも防ぐ。
    for _ in 0..4 * n * n {
        points.push((c as f64 + 0.5, r as f64 + 0.5));
        d = reflect(output.board[r as usize][c as usize], d);
        r += DR[d];
        c += DC[d];
        if let Some(exit) = exit_index(n, r, c) {
            points.push(port_point(n, exit));
            return Ok(Route { exit, points });
        }
    }
    Err(format!("入口 {entry} の経路が盤面から出ません"))
}

#[derive(Clone, Debug)]
pub struct Evaluation {
    pub score: i64,
    pub inversions: i64,
    pub b: Vec<usize>,
    pub routes: Vec<Route>,
}

pub fn evaluate(input: &Input, output: &Output) -> Result<Evaluation, String> {
    let m = 4 * input.n;
    let mut b = vec![0; m];
    let mut routes = Vec::with_capacity(m);
    for i in 0..m {
        let route = trace(input, output, i)?;
        if b[route.exit] != 0 {
        return Err(format!("ポート {} に複数のレーザー光が到達しました", route.exit));
        }
        b[route.exit] = input.a[i];
        routes.push(route);
    }
    let inversions = (0..m)
        .map(|i| (i + 1..m).filter(|&j| b[i] > b[j]).count() as i64)
        .sum();
    Ok(Evaluation {
        score: (m * (m - 1) / 2) as i64 - inversions,
        inversions,
        b,
        routes,
    })
}

impl Evaluation {
    pub fn json(&self) -> String {
        let destinations: Vec<_> = self.routes.iter().map(|r| r.exit).collect();
        format!(
            "{{\"score\":{},\"inversions\":{},\"b\":{:?},\"destinations\":{:?}}}",
            self.score, self.inversions, self.b, destinations
        )
    }
}

#[derive(Default)]
pub struct VisOptions {
    pub entry: Option<usize>,
    pub steps: Option<usize>,
    pub all_paths: bool,
    pub labels: bool,
    pub input_labels: bool,
    pub direction_arrows: bool,
    pub hover_entry: Option<usize>,
    pub hover_cell: Option<(usize, usize)>,
}

/// 青 → 緑 → 赤の順で RGB 値を連続的に補間する。
pub fn ball_color(value: usize, m: usize) -> String {
    let t = (value - 1) as f64 / (m - 1) as f64;
    let (a, b, t) = if t <= 0.5 {
        ([37., 99., 235.], [22., 163., 74.], t * 2.)
    } else {
        ([22., 163., 74.], [220., 38., 38.], (t - 0.5) * 2.)
    };
    let mix = |a: f64, b: f64| (a + (b - a) * t).round() as u8;
    format!(
        "rgb({},{},{})",
        mix(a[0], b[0]),
        mix(a[1], b[1]),
        mix(a[2], b[2])
    )
}

pub fn svg(input: &Input, output: &Output, ev: &Evaluation, opt: &VisOptions) -> String {
    let n = input.n;
    let cell = 760. / n as f64;
    let size = (cell * 0.92).min(90.);
    let radius = if opt.input_labels {
        (cell * 0.14).min(18.)
    } else {
        (cell * 0.22).min(10.)
    };
    let input_offset = radius + 2.;
    // 番号の文字サイズ。桁数によらず全ポートで同じ大きさにし、最大桁数（M の桁数）の
    // 番号が四角に収まる大きさ（太字の数字幅を約 0.6em と見積もる）を使う。
    let digits = (4 * n).to_string().len() as f64;
    let label_font = (size * 0.85 / (0.6 * digits)).min(size * 0.7).min(60.);
    // 番号表示時は、入口の丸と受信の四角の間に入口番号を置く場所を空ける。
    let entry_labels = opt.labels && !opt.input_labels;
    let label_space = if entry_labels {
        0.6 * digits * label_font + 4.
    } else {
        0.
    };
    let output_offset = 2. * radius + size / 2. + 6. + label_space;
    let margin = (output_offset + size / 2. + 6.).max(45.);
    // 光の線を、盤面の外周から受信の四角の縁まで伸ばす（単位はマス）。
    let tail = (output_offset - size / 2.) / cell;
    let beam = |i: usize| with_tail(display_points(ev, i, cell), tail);
    let extent = 760. + 2. * margin;
    let mut s = format!(
        r##"<svg xmlns="http://www.w3.org/2000/svg" viewBox="-{margin} -{margin} {extent} {extent}" width="{extent}" height="{extent}" role="img" aria-label="Spectrum Router 盤面"><rect x="-{margin}" y="-{margin}" width="{extent}" height="{extent}" fill="white"/><g font-family="sans-serif">"##
    );
    for i in 0..=n {
        let p = i as f64 * cell;
        write!(s, r##"<path d="M{p},0 V760 M0,{p} H760" stroke="#dce3eb" stroke-width="0.7" fill="none"/>"##).unwrap();
    }
    for r in 0..n {
        for c in 0..n {
            let (x, y) = (c as f64 * cell, r as f64 * cell);
            let (x2, y2) = (x + cell, y + cell);
            match output.board[r][c] {
                b'/' => write!(
                    s,
                    r##"<path d="M{x},{y2} L{x2},{y}" stroke="#334155" stroke-width="{}"/>"##,
                    (cell * 0.075).clamp(1., 4.)
                )
                .unwrap(),
                b'\\' => write!(
                    s,
                    r##"<path d="M{x},{y} L{x2},{y2}" stroke="#334155" stroke-width="{}"/>"##,
                    (cell * 0.075).clamp(1., 4.)
                )
                .unwrap(),
                _ => (),
            }
        }
    }
    if opt.all_paths {
        // 往復の光は左右に分けて描くので、すべての入口の光を描く。
        for i in 0..4 * n {
            let color = ball_color(input.a[i], 4 * n);
            draw_path(&mut s, &beam(i), cell, &color, 0.32);
        }
    }
    // hover したセルを通るすべてのレーザー経路（逆向きも含む）を表示する。
    let highlights: Vec<_> = (0..4 * n)
        .filter(|&i| {
            opt.hover_entry == Some(i)
                || opt.hover_cell.is_some_and(|(r, c)| {
                    ev.routes[i]
                        .points
                        .iter()
                        .any(|&(x, y)| x == c as f64 + 0.5 && y == r as f64 + 0.5)
                })
        })
        .collect();
    if let Some((r, c)) = opt.hover_cell {
        write!(s,r##"<rect x="{}" y="{}" width="{cell}" height="{cell}" fill="#facc15" opacity="0.35"/>"##,c as f64*cell,r as f64*cell).unwrap();
    }
    for &i in &highlights {
        // ハイライトした光は、全経路表示の薄い線より太く濃く描く。
        draw_path_scaled(&mut s, &beam(i), cell, &ball_color(input.a[i], 4 * n), 1., 1.6);
    }
    if let Some(i) = opt.entry.filter(|&i| i < 4 * n) {
        let points = &beam(i);
        let count = opt.steps.unwrap_or(points.len() - 1).min(points.len() - 1) + 1;
        let color = if opt.direction_arrows {
            ball_color(input.a[i], 4 * n)
        } else {
            "#ea580c".to_owned()
        };
        if opt.direction_arrows {
            draw_directed_path(&mut s, &points[..count], cell, &color, 1.);
        } else {
            draw_path(&mut s, &points[..count], cell, &color, 1.);
        }
        let (x, y) = points[count - 1];
        write!(s, r##"<circle cx="{}" cy="{}" r="{}" fill="{color}" stroke="white" stroke-width="1.5"/>"##, x*cell,y*cell,(cell*0.17).clamp(3.,8.)).unwrap();
    }
    // 最前面の透明マスは Web 版の編集操作にも使う。
    for r in 0..n {
        for c in 0..n {
            write!(s, r##"<rect data-row="{r}" data-col="{c}" x="{}" y="{}" width="{cell}" height="{cell}" fill="transparent"><title>({r},{c})</title></rect>"##, c as f64*cell,r as f64*cell).unwrap();
        }
    }
    for i in 0..4 * n {
        let (px, py) = port_point(n, i);
        let (x, y) = (px * cell, py * cell);
        let (dx, dy) = match i / n {
            0 => (0., -1.),
            1 => (1., 0.),
            2 => (0., 1.),
            _ => (-1., 0.),
        };
        let origin = ev.routes[i].exit;
        let input_active = highlights.contains(&i) || opt.entry == Some(i);
        let input_color = ball_color(input.a[i], 4 * n);
        let (ix, iy) = (x + dx * input_offset, y + dy * input_offset);
        write!(s,r##"<g data-entry="{i}" data-port="{i}" data-kind="入力" cursor="pointer"><title>{}</title><circle data-ball="input" cx="{ix}" cy="{iy}" r="{radius}" fill="{input_color}" stroke="{}" stroke-width="{}"/>"##,input.a[i],if input_active {"#0f172a"} else {"#3b82f6"},if input_active {2.5} else {0.8}).unwrap();
        if entry_labels {
            let t = radius + 2. + label_space / 2.;
            let (lx, ly) = (ix + dx * t, iy + dy * t);
            write!(s, r##"<text x="{lx}" y="{ly}" text-anchor="middle" dominant-baseline="central" font-size="{label_font}" fill="{}" font-weight="{}" stroke="white" stroke-width="{}" paint-order="stroke">{}</text>"##, if input_active {"#0f172a"} else {"#475569"}, if input_active {"bold"} else {"normal"}, label_font * 0.3, input.a[i]).unwrap();
        }
        s.push_str("</g>");
        if opt.input_labels {
            let font = (cell * 0.16).min(40.);
            if i / n == 0 || i / n == 2 {
                write!(s, r##"<text x="{}" y="{iy}" text-anchor="start" dominant-baseline="central" font-size="{font}" fill="#111827" font-weight="bold" stroke="white" stroke-width="3" paint-order="stroke">{}</text>"##, ix + radius + 5., input.a[i]).unwrap();
            } else {
                write!(s, r##"<text x="{ix}" y="{}" text-anchor="middle" dominant-baseline="central" font-size="{font}" fill="#111827" font-weight="bold" stroke="white" stroke-width="3" paint-order="stroke">{}</text>"##, iy + radius + font / 2. + 4., input.a[i]).unwrap();
            }
        }
        let (value, entry, kind) = (ev.b[i], origin, "出力");
        let active = highlights.contains(&entry) || opt.entry == Some(entry);
        let color = ball_color(value, 4 * n);
        let (cx, cy) = (x + dx * output_offset, y + dy * output_offset);
        let (left, top) = (cx - size / 2., cy - size / 2.);
        write!(s, r##"<g data-entry="{entry}" data-port="{i}" data-kind="{kind}" cursor="pointer"><title>{value}</title><rect data-ball="output" x="{left}" y="{top}" width="{size}" height="{size}" fill="{color}" stroke="{}" stroke-width="{}"/>"##,if active {"#0f172a"}else{"#64748b"},if active {2.5}else{0.7}).unwrap();
        if opt.labels {
            let font = label_font;
            write!(s, r##"<text x="{cx}" y="{cy}" text-anchor="middle" dominant-baseline="central" font-size="{font}" fill="white" font-weight="bold" pointer-events="none">{value}</text>"##).unwrap();
        }
        s.push_str("</g>");
    }
    s.push_str("</g></svg>");
    s
}

/// 経路を中心線から平行にずらす量（単位はマス）。
/// 小さい盤面で線が入口の丸から離れすぎないよう、8px を上限にする。
fn path_shift(cell: f64) -> f64 {
    0.16_f64.min(8. / cell)
}

/// 経路を中心線から距離 |d| だけ平行にずらす。最初の線分は進行方向の右側
/// （d < 0 なら左側）にずらし、鏡で反射するたびに実際の光と同じく反対側へ移る。
/// こうすると曲がり角がちょうど鏡の線上にくる。
fn shift_points(points: &[(f64, f64)], d: f64) -> Vec<(f64, f64)> {
    // 線分 a→b の進行方向に対する右向きの単位法線（画面座標: y は下向き）。
    let normal = |a: (f64, f64), b: (f64, f64)| {
        let (dx, dy) = (b.0 - a.0, b.1 - a.1);
        let len = dx.hypot(dy);
        if len == 0. {
            (0., 0.)
        } else {
            (-dy / len, dx / len)
        }
    };
    let mut side = d;
    (0..points.len())
        .map(|k| {
            let p = points[k];
            let n_in = (k > 0).then(|| normal(points[k - 1], p));
            let n_out = (k + 1 < points.len()).then(|| normal(p, points[k + 1]));
            match (n_in, n_out) {
                (Some(a), Some(b)) if a != b => {
                    // 反射: 入射側は side、反射後は -side。両者の交点は鏡の線上にある。
                    let q = (
                        p.0 + a.0 * side - b.0 * side,
                        p.1 + a.1 * side - b.1 * side,
                    );
                    side = -side;
                    q
                }
                (Some(a), _) | (None, Some(a)) => (p.0 + a.0 * side, p.1 + a.1 * side),
                (None, None) => p,
            }
        })
        .collect()
}

/// 入口 i の光を描く座標（単位はマス）。往復で同じ道を通る 2 本の光は、
/// 番号の小さい入口側を基準に、もう一方をちょうど反対側に描いて重ならないようにする。
/// 経路の終点を、最後の進行方向へ len マスだけ延長する。
fn with_tail(mut points: Vec<(f64, f64)>, len: f64) -> Vec<(f64, f64)> {
    if let [.., a, b] = points[..] {
        let (dx, dy) = (b.0 - a.0, b.1 - a.1);
        let l = dx.hypot(dy);
        if l > 0. {
            points.push((b.0 + dx / l * len, b.1 + dy / l * len));
        }
    }
    points
}

fn display_points(ev: &Evaluation, i: usize, cell: f64) -> Vec<(f64, f64)> {
    let d = path_shift(cell);
    let exit = ev.routes[i].exit;
    if i <= exit {
        shift_points(&ev.routes[i].points, d)
    } else {
        let mut v = shift_points(&ev.routes[exit].points, -d);
        v.reverse();
        v
    }
}

fn draw_path(s: &mut String, points: &[(f64, f64)], cell: f64, color: &str, opacity: f64) {
    draw_path_scaled(s, points, cell, color, opacity, 1.);
}

/// 線幅を通常の scale 倍にして経路を描く。
fn draw_path_scaled(
    s: &mut String,
    points: &[(f64, f64)],
    cell: f64,
    color: &str,
    opacity: f64,
    scale: f64,
) {
    let data = points
        .iter()
        .map(|&(x, y)| format!("{},{}", x * cell, y * cell))
        .collect::<Vec<_>>()
        .join(" ");
    write!(s, r#"<polyline points="{data}" stroke="{color}" stroke-width="{}" opacity="{opacity}" fill="none" stroke-linejoin="round" stroke-linecap="round"/>"#, (cell*0.1).clamp(1.3,4.)*scale).unwrap();
}

fn draw_directed_path(s: &mut String, points: &[(f64, f64)], cell: f64, color: &str, opacity: f64) {
    draw_path(s, points, cell, color, opacity);
    let arrow_len = (cell * 0.18).clamp(6., 24.);
    for pair in points.windows(2) {
        let ((x1, y1), (x2, y2)) = (pair[0], pair[1]);
        let (dx, dy) = ((x2 - x1) * cell, (y2 - y1) * cell);
        let len = dx.hypot(dy);
        if len == 0. {
            continue;
        }
        let (ux, uy) = (dx / len, dy / len);
        let (nx, ny) = (-uy, ux);
        let (mx, my) = ((x1 + x2) * cell / 2., (y1 + y2) * cell / 2.);
        let tip = (mx + ux * arrow_len / 2., my + uy * arrow_len / 2.);
        let base = (mx - ux * arrow_len / 2., my - uy * arrow_len / 2.);
        let half_width = arrow_len * 0.38;
        let left = (base.0 + nx * half_width, base.1 + ny * half_width);
        let right = (base.0 - nx * half_width, base.1 - ny * half_width);
        write!(
            s,
            r##"<polygon points="{},{} {},{} {},{}" fill="{color}" opacity="{opacity}"/>"##,
            tip.0, tip.1, left.0, left.1, right.0, right.1
        )
        .unwrap();
    }
}

pub fn html(input: &Input, output: &Output, ev: &Evaluation, opt: &VisOptions) -> String {
    format!(
        r#"<!doctype html><html lang="ja"><meta charset="utf-8"><title>Spectrum Router</title><style>body{{font-family:sans-serif;margin:12px;color:#222}}h1{{font-size:20px}}svg{{display:block;max-width:100%;max-height:calc(100dvh - 155px);width:auto;height:auto}}p{{font-size:13px}}</style><h1>Spectrum Router</h1><p>Score: <strong>{}</strong></p>{}</html>"#,
        ev.score,
        svg(input, output, ev, opt)
    )
}
