- [Usage](#usage)
  - [Requirements](#requirements)
  - [Input Generation](#input-generation)
  - [Local Tester](#local-tester)
  - [Scoring](#scoring)
  - [Visualization](#visualization)
  - [Porting to other languages](#porting-to-other-languages)
- [使い方](#%E4%BD%BF%E3%81%84%E6%96%B9)
  - [実行環境](#%E5%AE%9F%E8%A1%8C%E7%92%B0%E5%A2%83)
  - [入力生成](#%E5%85%A5%E5%8A%9B%E7%94%9F%E6%88%90)
  - [ローカルテスタ](#%E3%83%AD%E3%83%BC%E3%82%AB%E3%83%AB%E3%83%86%E3%82%B9%E3%82%BF)
  - [スコア計算](#%E3%82%B9%E3%82%B3%E3%82%A2%E8%A8%88%E7%AE%97)
  - [ビジュアライザ](#%E3%83%93%E3%82%B8%E3%83%A5%E3%82%A2%E3%83%A9%E3%82%A4%E3%82%B6)
  - [他言語への移植](#%E4%BB%96%E8%A8%80%E8%AA%9E%E3%81%B8%E3%81%AE%E7%A7%BB%E6%A4%8D)

# Usage

## Requirements
Please install a compiler for Rust language (see https://www.rust-lang.org).
If a compile error occurs, the compiler version may be old.
You can update to the latest compiler by executing the following command.
```
rustup update
```

The following examples assume that you will be working in the directory where this README is located.

## Input Generation
The `in` directory contains pre-generated input files for seed=0-99.
If you want more inputs, prepare `seeds.txt` which contains a list of random seeds (unsigned 64bit integers, separated by whitespace) and execute the following command.
```
cargo run -r --bin gen seeds.txt
```
This will output input files `0000.txt`, `0001.txt`, ... into `in` directory, one for each seed in `seeds.txt`.

The following options are available.
```
cargo run -r --bin gen seeds.txt [--dir in] [--n 64] [--verbose]
```
- `--dir <DIR>`, `-d <DIR>`: output directory (default: `in`). It is created if it does not exist.
- `--n <N>`: board size N (default: 64; must be in 1..=100).
- `--verbose`, `-v`: prints a CSV list (`file,seed,n`) of the generated files to standard output.

## Local Tester
Let `in.txt` be an input file, `out.txt` be a file to which output of your program will be written, and `cmd` be a command to run your program.
You can test your program by executing the following command.
```
cargo run -r --bin tester -- cmd < in.txt > out.txt
```
The tester runs `cmd`, feeds it `in.txt`, and writes your program's standard output to `out.txt`.
Your program's standard error is passed through as is.
The score (`Score`), the number of inversions (`Inversions`) and the elapsed time (`Elapsed`) are printed to standard error.
If the program fails (runtime error, time limit exceeded, output larger than 1 MiB, invalid output, etc.), the tester prints `Error: ...` and `Score = 0` to standard error and exits with a non-zero status.

You can specify arguments to your program by
```
cargo run -r --bin tester -- cmd arg1 arg2 ... < in.txt > out.txt
```

The time limit can be changed with `--timeout <SECONDS>` (default: 5), which must be placed before `--`.
```
cargo run -r --bin tester -- --timeout 5 cmd < in.txt > out.txt
```

You can visualize the contents of the output file by passing it to the `vis` command described below, or by using the web visualizer.

### Examples
When executing a binary `a.out` which has been compiled in C++, etc.
```
cargo run -r --bin tester -- ./a.out < in.txt > out.txt
```

When executing a program `main.py` using python3.
```
cargo run -r --bin tester -- python3 main.py < in.txt > out.txt
```

## Scoring
You can compute the score of an existing output file without running your program.
```
cargo run -r --bin score -- in.txt out.txt
```
This prints `Score = ...` and `Inversions = ...` to standard output.
With `--json`, the result is printed as a single JSON line containing `score`, `inversions`, `b` and `destinations`.
```
cargo run -r --bin score -- in.txt out.txt --json
```
If the output is invalid, `Error: ...` and `Score = 0` are printed to standard error and the exit status is non-zero.

## Visualization
Let `in.txt` be an input file and `out.txt` be an output file.
You can visualize the output by executing the following command.
```
cargo run -r --bin vis -- in.txt out.txt
```

The above command writes a visualization result to `vis.html`.
It also outputs `Score`, `Inversions` and the path of the written file to standard output.
If the output file is invalid, `WA: ...` is printed to standard error, `Score = 0` is printed to standard output, and `vis.html` is not written.

The following options are available.
```
cargo run -r --bin vis -- in.txt out.txt [--entry 0] [--all-paths] [--input-labels] [--direction-arrows] [--file vis.html]
```
- `--entry <PORT>`: highlights the path of the laser that enters from the specified port (an integer in 0..4N-1).
- `--all-paths`: draws the paths of all lasers.
- `--input-labels`: shows the input values next to the entry balls instead of between the entry balls and the receivers.
- `--direction-arrows`: draws the path specified by `--entry` with direction arrows, colored according to the value of the laser.
- `--no-labels`: hides the numbers drawn on the receivers (and the input values between the entry balls and the receivers).
- `--file <PATH>`: output file name (default: `vis.html`).

You can also use a [web visualizer](https://<GitHub Pages の公開URL>/) which is more rich in features.

## Porting to other languages
Input generation, validation of the input/output format, and the score computation are all contained in `src/lib.rs`.
If you want to port them to another language, that file is the one you need.
`src/lib.rs` also contains the SVG drawing code used by `vis`, but it does not need to be ported.

# 使い方

## 実行環境
Rust言語のコンパイル環境が必要です。
https://www.rust-lang.org/ja を参考に各自インストールして下さい。
コンパイルエラーになった場合、コンパイラのバージョンが古い可能性があります。
以下のコマンド実行することで最新のコンパイラに更新が可能です。
```
rustup update
```

以下の実行例では、このREADMEが置かれているディレクトリに移動して作業することを想定しています。

## 入力生成
`in` ディレクトリに予め生成された seed=0~99 に対する入力ファイルが置かれています。
より多くの入力が欲しい場合は、`seeds.txt` に欲しい入力ファイルの数だけ乱数seed値(符号なし64bit整数値、空白区切り)を記入し、以下のコマンドを実行します。
```
cargo run -r --bin gen seeds.txt
```
生成された入力ファイル `0000.txt`, `0001.txt`, ... は、`seeds.txt` の各seedに対応して `in` ディレクトリに出力されます。

以下のオプションが利用できます。
```
cargo run -r --bin gen seeds.txt [--dir in] [--n 64] [--verbose]
```
- `--dir <DIR>`, `-d <DIR>`: 出力先ディレクトリ(デフォルトは `in`)。存在しない場合は作成されます。
- `--n <N>`: 盤面のサイズ N(デフォルトは 64、1 以上 100 以下)。
- `--verbose`, `-v`: 生成したファイルの一覧を CSV 形式(`file,seed,n`)で標準出力に表示します。

## ローカルテスタ
入力ファイル名を`in.txt`、出力結果を書き出す先のファイル名を`out.txt`、あなたのプログラムの実行コマンドを`cmd`としたとき、以下のコマンドを実行します。

```
cargo run -r --bin tester -- cmd < in.txt > out.txt
```
テスタは `cmd` を実行して `in.txt` を入力として与え、あなたのプログラムの標準出力を `out.txt` に書き出します。
プログラムの標準エラー出力はそのまま表示されます。
スコア(`Score`)、逆順対の数(`Inversions`)、実行時間(`Elapsed`)は標準エラー出力に表示されます。
プログラムの異常終了・時間超過・1 MiB を超える出力・不正な出力などの場合は、標準エラー出力に `Error: ...` と `Score = 0` を表示し、0 以外のステータスで終了します。

引数が必要な場合には
```
cargo run -r --bin tester -- cmd arg1 arg2 ... < in.txt > out.txt
```
のようにします。

制限時間は `--timeout <秒>`(デフォルトは 5)で変更できます。`--` より前に指定して下さい。
```
cargo run -r --bin tester -- --timeout 5 cmd < in.txt > out.txt
```

出力された `out.txt` は、後述の `vis` コマンドまたはウェブ版のビジュアライザでビジュアライズできます。

### 例
C++などでコンパイル済みの `a.out` というバイナリを実行する場合
```
cargo run -r --bin tester -- ./a.out < in.txt > out.txt
```

python3 で `main.py` というプログラムを実行する場合
```
cargo run -r --bin tester -- python3 main.py < in.txt > out.txt
```

## スコア計算
プログラムを実行せずに、既にある出力ファイルのスコアだけを計算できます。
```
cargo run -r --bin score -- in.txt out.txt
```
標準出力に `Score = ...` と `Inversions = ...` が表示されます。
`--json` を付けると、`score`・`inversions`・`b`・`destinations` を含む 1 行の JSON を出力します。
```
cargo run -r --bin score -- in.txt out.txt --json
```
出力が不正な場合は、標準エラー出力に `Error: ...` と `Score = 0` を表示し、0 以外のステータスで終了します。

## ビジュアライザ
入力ファイル名を`in.txt`、出力ファイル名を`out.txt`としたとき、以下のコマンドを実行します。
```
cargo run -r --bin vis -- in.txt out.txt
```

出力のビジュアライズ結果は `vis.html` というファイルに書き出されます。
標準出力には `Score`、`Inversions`、書き出したファイルのパスを出力します。
出力ファイルが不正な場合は、標準エラー出力に `WA: ...` を、標準出力に `Score = 0` を表示し、`vis.html` は書き出されません。

以下のオプションが利用できます。
```
cargo run -r --bin vis -- in.txt out.txt [--entry 0] [--all-paths] [--input-labels] [--direction-arrows] [--file vis.html]
```
- `--entry <ポート番号>`: 指定したポート(0 以上 4N-1 以下の整数)から入るレーザー光の経路を強調して描きます。
- `--all-paths`: すべてのレーザー光の経路を描きます。
- `--input-labels`: 入力値を、入口の丸と受信の四角の間ではなく、入口の丸の横に表示します。
- `--direction-arrows`: `--entry` で指定した経路を、光の値に応じた色の方向矢印付きで描きます。
- `--no-labels`: 受信の四角に描かれる数字(および入口の丸と受信の四角の間の入力値)を非表示にします。
- `--file <パス>`: 出力ファイル名(デフォルトは `vis.html`)。

より機能が豊富な[ウェブ版のビジュアライザ](https://<GitHub Pages の公開URL>/)も利用可能です。

## 他言語への移植
入力生成・入出力形式の検証・スコア計算は、すべて `src/lib.rs` に含まれています。
他言語へ移植したい場合、対象はこのファイルです。
`src/lib.rs` には `vis` 用の SVG 描画コードも含まれていますが、移植は不要です。
